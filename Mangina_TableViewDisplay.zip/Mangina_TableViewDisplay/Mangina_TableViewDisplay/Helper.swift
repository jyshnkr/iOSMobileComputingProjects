//
//  Helper.swift
//  Mangina_TableViewDisplay
//
//  Created by JayaShankar Mangina on 11/18/21.
//

import Foundation
import UIKit

struct secondVC {
    var prod: [String]
}

struct thirdVC {
    var image: [String]
    var prodInfo: [String]
}
